# 上节回顾

```python
# 前端发展历史
	-render显示---》ajax出现---（ajax+dom）--》前端写很多页面html，js，css---》vue，react---》一套代码，处处运行(谷歌，uni-app)
# vue的介绍
	-js框架，vue2     vue3 
  -MVVM架构： m：model(js中数据)   v：view  vm:ViewModel   页面变，数据跟着变，数据变页面也变化
  -组件化开发
  -单页面开发---》页面间的跳转(vue-router)
# vue的快速使用
	-引入vue，new Vue实力，传入一些配置项，在被vue管理的标签中使用vue语法
# 插值语法
	-{{变量，简单的表达式，函数}}
  -三目运算符---》python中的三元表达式
# 指令只v-html和v-text
	-v-xx 写法，写在标签上的，统称为vue的指令 
  -<p v-html=''></p>    xss攻击
  -v-text
# v-if和v-show
	-控制标签显示与隐藏
# 双向数据绑定演示
	
# v-on 事件指令
	-点击事件，双击事件，失去焦点。。。。
  -@事件名='函数'
	-v-on:事件名='函数'，methods:{  handleClick(){},}
  -es6的对象写法
  	{变量，变量}
    {函数名(){},}
# 属性指令v-bind
	-标签上的属性可以动态变化---》js的变量
  -任意标签的任意属性上：name，id，class，style，src，href，自己定义的属性
  -<p id='id_p' class='red' :aa='aaaaa'></p>
  -img：src，a：href属性
  -v-bind:src=''
  -简写:src=''
# style和class的绑定
	-class和style比较特殊的属性，控制样式
  -:class= 字符串(空格表示多个类)，数组(合适)，对象(key值是类名，value值是布尔值)
  -:style= 字符串，数组(对象)，对象
  -css中两个单词是用 font-size---》fontSize
  -<p :style='{fontSize="30px"}'></p>
# 条件渲染
	-v-if=条件   v-else-if=条件   v-else
# 列表渲染v-for
	-放在标签上，循环多少次，标签就会显示多少次
  -v-for='item in 数组，对象，数字'
# 购物车显示不显示小案例
# v-model的使用
	-针对于input标签 :value='变量'，单向数据绑定
	-双向数据绑定：v-model='变量'
# blur，change，input事件
	-input标签的 失去焦点，变化，输入内容就变化的事件
# 过滤案例
# 事件修饰符
	-按钮只能点击一次
  -只响应自己对事件
  -阻止a标签跳转
  -阻止事件冒泡
# 按键修饰符
	-@keyup="handleKey1"---》监控到用户点击那个键
```



# 今日内容

## 1 表单控制

```python
# form表单---》input标签，单选，多选按钮
# 单选，多选的  v-model的绑定

# 1 checkbox的单选---》v-model绑定一个布尔值---》只要选中布尔就为true，反之亦然
# 2 radio的单选----》v-model绑定字符串----》选中字符串就是value对应的值
# 3 checkbox的多选---》v-model绑定一个数组---》多个选中，数组就有多个值
```

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <h1>表单控制之checkbox单选</h1>

        <p>用户名：<input type="text" v-model="username"></p>
        <p>密码：<input type="password" v-model="password"></p>
        <p><input type="checkbox" v-model="isCheck">记住密码</p>
        <p>
            <input type="radio" v-model="gender" value="1">男
            <input type="radio" v-model="gender" value="2">女
            <input type="radio" v-model="gender" value="0">未知
        </p>
        <p>爱好(多选)：</p>
        <p>
            <input type="checkbox" v-model="hobby" value="篮球"> 篮球
            <input type="checkbox" v-model="hobby" value="足球"> 足球
            <input type="checkbox" v-model="hobby" value="橄榄球"> 橄榄球
            <input type="checkbox" v-model="hobby" value="乒乓球"> 乒乓球
        </p>
<!--        <hr>-->
<!--        密码是否选中：{{isCheck}}-->
<!--        <hr>-->
<!--        性别是：{{gender}}-->
<!--        <hr>-->
<!--        爱好是：{{hobby}}-->

        <hr>
        <input type="submit" value="提交" @click="handleSubmit">



</div>

</body>
<script>
    var vm = new Vue({
        el: '.app',
        data: {
            username: '',
            password: '',
            isCheck: false,
            gender: '',
            hobby:[],
        },
        methods: {
            handleSubmit(){
                //假设发送ajax到后端了
                console.log(this.username)
                console.log(this.password)
                console.log(this.isCheck)
                console.log(this.gender)
                console.log(this.hobby)
            }
        },


    })
</script>
</html>
```



## 2 购物车案例

### 2.1 js的循环方式

```python
# python，js，go，java  for循环的区别
	-python中只for循环有基于迭代的循环，没有基于索引的循环
      for xx in 可迭代对象  # 基于迭代
  -js ：
  		for xx in 对象  # 基于迭代
      for i=0;i<10;i++  # 基于索引
  -go：
     for i=0;i<10;i++  # 基于索引
     for item range 变量  # 基于迭代
      
  -java：
  		for i=0;i<10;i++  # 基于索引  1.8之前只有这种
      for xx in 对象  # 基于迭代   1.8后的语法


# 1 方式一：最基本的
for (let i=0; i<3; i++) {
  console.log(i)
}

# 2 in 循环  es5的语法
for(let 成员 in 对象){
    循环的代码块
  
  
# 3 for of   es6的循环
  for(item of arr){
    console.log('item =>', item)
  }
  
 
# 4 数组foreach循环 (数组)
   var a=[33,22,888]
   a.forEach(function (value,index){
        console.log(value)
        console.log(index)
    })

# 5 jq  $each 循环
$.each(可迭代对象,function (key,value) {
  });
 
var a=[33,22,888]
 // var obj={name:'lqz',age:19}
 $.each(a,function (key,value){
       console.log(key)
       console.log(value)
   })

```

### 2.2 基本购物车

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="./js/vue.js"></script>
    <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
</head>
<body>
<div class="app">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div style="margin-top: 30px">
                    <h1>购物车案例</h1>
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>商品id</th>
                            <th>商品名字</th>
                            <th>商品价格</th>
                            <th>商品数量</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr v-for="good in goodList">
                            <th>{{good.id}}</th>
                            <td>{{good.name}}</td>
                            <td>{{good.price}}</td>
                            <td>{{good.count}}</td>
                            <td><input type="checkbox" v-model="buyGoods" :value="good"></td>
                        </tr>
                        </tbody>
                    </table>
                    <hr>
                    选中的商品:{{buyGoods}}
                    <hr>
                    总价格是：{{getPrice()}}
                </div>


            </div>

        </div>

    </div>

</div>

</body>
<script>
    var vm = new Vue({
        el: '.app',
        data: {
            goodList: [
                {id: '1', name: '小汽车', price: 150000, count: 2},
                {id: '2', name: '鸡蛋', price: 2, count: 1},
                {id: '3', name: '饼干', price: 10, count: 6},
                {id: '4', name: '钢笔', price: 15, count: 5},
                {id: '5', name: '脸盆', price: 30, count: 3},
            ],
            buyGoods:[],
        },
        methods:{
            getPrice(){
                var total=0
                // 方式一：数组的循环：循环计算选中的商品价格
                // this.buyGoods.forEach(function (v,i){
                //     total+=v.price*v.count
                // })

                // 方式二：es6 的 of 循环
                for (item of this.buyGoods){
                    // console.log(item)
                    total+=item.price*item.count
                }
                return total
            }
        }


    })


    // var a=[33,22,888]
    // a.forEach(function (value,index){
    //     console.log(value)
    //     console.log(index)
    // })
    // 对象没有forEach

    // jq 的循环
   //  var a=[33,22,888]
   //  // var obj={name:'lqz',age:19}
   // $.each(a,function (key,value){
   //     console.log(key)
   //     console.log(value)
   // })
</script>
</html>
```



### 2.3 带全选，全不选

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div style="margin-top: 30px">
                    <h1>购物车案例</h1>
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>商品id</th>
                            <th>商品名字</th>
                            <th>商品价格</th>
                            <th>商品数量</th>
                            <th><input type="checkbox" v-model="checkAll" @change="handleCheckAll"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr v-for="good in goodList">
                            <th>{{good.id}}</th>
                            <td>{{good.name}}</td>
                            <td>{{good.price}}</td>
                            <td>{{good.count}}</td>
                            <td><input type="checkbox" v-model="buyGoods" :value="good" @change="handleCheckOne"></td>
                        </tr>
                        </tbody>
                    </table>
                    <hr>
                    选中的商品:{{buyGoods}}
                    <hr>
                    总价格是：{{getPrice()}}
                </div>


            </div>

        </div>

    </div>

</div>

</body>
<script>
    var vm = new Vue({
        el: '.app',
        data: {
            goodList: [
                {id: '1', name: '小汽车', price: 150000, count: 2},
                {id: '2', name: '鸡蛋', price: 2, count: 1},
                {id: '3', name: '饼干', price: 10, count: 6},
                {id: '4', name: '钢笔', price: 15, count: 5},
                {id: '5', name: '脸盆', price: 30, count: 3},
            ],
            buyGoods:[],
            checkAll:false,
        },
        methods:{
            getPrice(){
                var total=0
                // 方式二：es6 的 of 循环
                for (item of this.buyGoods){
                    // console.log(item)
                    total+=item.price*item.count
                }
                return total
            },
            handleCheckAll(){
                if(this.checkAll){
                    // 用户全选了，只需要把 buyGoods的值变为goodList
                    this.buyGoods=this.goodList
                }else {
                    this.buyGoods=[]
                }
            },
            handleCheckOne(){
                // 判断buyGoods长度，是否等于goodList，如果等于说明用户全选了，把checkAll设置为true
                // 否则设置为false
                // if(this.buyGoods.length==this.goodList.length){
                //     // 说明用户通过单选，选全了
                //     this.checkAll=true
                // }else {
                //     this.checkAll=false
                // }
                // 简写成
                this.checkAll=(this.buyGoods.length==this.goodList.length)
            }
        }


    })

</script>
</html>
```

### 2.4 带加减

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div style="margin-top: 30px">
                    <h1>购物车案例</h1>
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>商品id</th>
                            <th>商品名字</th>
                            <th>商品价格</th>
                            <th>商品数量</th>
                            <th><input type="checkbox" v-model="checkAll" @change="handleCheckAll"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr v-for="good in goodList">
                            <th>{{good.id}}</th>
                            <td>{{good.name}}</td>
                            <td>{{good.price}}</td>
                            <td><button @click="handleJian(good)">-</button>{{good.count}}<button @click="good.count++">+</button></td>
                            <td><input type="checkbox" v-model="buyGoods" :value="good" @change="handleCheckOne"></td>
                        </tr>
                        </tbody>
                    </table>
                    <hr>
                    选中的商品:{{buyGoods}}
                    <hr>
                    总价格是：{{getPrice()}}
                </div>


            </div>

        </div>

    </div>

</div>

</body>
<script>
    var vm = new Vue({
        el: '.app',
        data: {
            goodList: [
                {id: '1', name: '小汽车', price: 150000, count: 2},
                {id: '2', name: '鸡蛋', price: 2, count: 1},
                {id: '3', name: '饼干', price: 10, count: 6},
                {id: '4', name: '钢笔', price: 15, count: 5},
                {id: '5', name: '脸盆', price: 30, count: 3},
            ],
            buyGoods:[],
            checkAll:false,
        },
        methods:{
            getPrice(){
                var total=0
                // 方式二：es6 的 of 循环
                for (item of this.buyGoods){
                    // console.log(item)
                    total+=item.price*item.count
                }
                return total
            },
            handleCheckAll(){
                if(this.checkAll){
                    // 用户全选了，只需要把 buyGoods的值变为goodList
                    this.buyGoods=this.goodList
                }else {
                    this.buyGoods=[]
                }
            },
            handleCheckOne(){
                // 判断buyGoods长度，是否等于goodList，如果等于说明用户全选了，把checkAll设置为true
                // 否则设置为false
                // if(this.buyGoods.length==this.goodList.length){
                //     // 说明用户通过单选，选全了
                //     this.checkAll=true
                // }else {
                //     this.checkAll=false
                // }
                // 简写成
                this.checkAll=(this.buyGoods.length==this.goodList.length)
            },
            handleJian(item){
                if(item.count<=1){
                    alert('太少了，受不了了')
                }else {
                    item.count--
                }
            }
        }


    })

</script>
</html>
```



## 3 v-model进阶

```python
# v-model 进阶之 
lazy：双向数据绑定，只要修改输入框的值，就再更新数据，耗费资源，加了lazy后，等不输入了，变量再变化
number：输入框，只接收数字部分，如果输入了  123asdfasd,只保留123 数字部分
trim：  去掉输入内容前后的空白
```

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <h1>v-model进阶</h1>
  <p><input type="text" v-model.lazy="a">{{a}}</p>
  <p><input type="text" v-model.number="b">{{b}}</p>
  <p><input type="text" v-model.trim="c">{{c}}</p>


</div>

</body>
<script>
    var vm = new Vue({
        el: '.app',
        data: {
          a:'',
          b:'',
          c:'',

        },



    })
</script>
</html>
```

## 4 Vue生命周期

```python
# 组件化开发
	vue的实例：vm
  以及后面学的组件：vc
  它们有生命周期：从创建开始，到销毁
  vue中总共生命周期有8个钩子函数(4对)，依次调用
  
  
  # 钩子的意思：aop的体现
  beforeCreate	创建Vue实例，组件实例对象创建 之前调用
  created	创建Vue实例成功后调用（咱们用的对，可以在此处发送ajax请求后端数据）
  
  beforeMount	渲染DOM之前调用
  mounted	渲染DOM之后调用
  ---初始化完成了----
  
  beforeUpdate	重新渲染之前调用（数据更新等操作时，控制DOM重新渲染）
  updated	重新渲染完成之后调用
  ---一直在转圈----
  
  ----销毁组件---
  beforeDestroy	销毁之前调用
  destroyed	销毁之后调用
  
  
  
  
  ##### 提前讲个组件的概念### 自己写的有html，有样式，有js的好看的可以复用的东西
  -完整看到组件的生命周期
  -vm实例的生命周期看不完整

  
  
  ###### 重点：
  	-created多一些：在这里面发送ajax请求，data的数据好了后，再发请求，去后端拿数据
    -updated：数据变化，页面更新完后，执行它
    -destroyed：组件销毁，会触发它，也会用
    		-组件创建了，起了个定时器，不停地打印hello world（每隔一段时间执行一个函数，延迟调用）
      	-如果组件销毁了，定时器没有被销毁，会出现定时器还在执行的情况，
        -所以要在destroyed中把定时器取消掉，资源清理工作
    -vm实例和组件实例都有8个生命周期钩子函数
    -只要写了钩子函数，就会执行，不写就不会执行
 
  
  
  # 面向过程编程
  # OOP编程：面向对象编程
  # AOP编程：面向切面编程（对面向对象编程的补充），java的spring框架大量的使用
  		-python中装饰器  AOP编程的体现
   		-drf源码，反序列化的源码，钩子函数，aop体现
  
```



## 5 与后端交互(ajax,fetch和axios)

```python
# 跨域问题： 前后端分离的项目会出现
	-浏览器有个安全策略：不允许向不同域(地址+端口号)发送请求获取数据，浏览器的 同源策略
  -解决跨域：
  	-后端的cors(跨域资源共享)技术：就是在响应头中加入允许即可
    -nginx做代理。。。
    
    
 # 原生js发送ajax请求，jq发送ajax请求，fetch发送ajax请求，axios发送ajax请求
	-原生：new XMLHttpRequest()   老api，坑很多
  -jq基于它封装，封装出了$.ajax ,屏蔽了很多问题
  -官方觉得XMLHttpRequest坑很多，搞了个fetch，跟XMLHttpRequest是平级的，比它好用，但是不支持ie
  -axios继续基于XMLHttpRequest封装了，一个发送ajax请求的模块
```



### 5.1 方式一：使用jq的ajax方法

```python
# 原生js写ajax，jq帮咱们写好了，处理好了浏览器版本间的不兼容，可以直接用

$.ajax({
                    url: 'http://127.0.0.1:8000/test/',
                    type: 'get',
                    success: data => {
                        // 后端返回json格式字符串，$.ajax拿到字符串，转成了js的对象，给了data
                        this.name = data.name
                        this.age = data.age
                    }
                })
```

### 5.2 方式二：使用fetch

```python
  fetch('http://127.0.0.1:8000/test/').then(res => res.json()).then(res => {
                console.log(res)
                this.name = res.name
                this.age = res.age
            })
```

### 5.3 方式三：使用第三方，axios(js模块)

```python
   <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
 
  
  axios.get('http://127.0.0.1:8000/test/').then(res=>{
            console.log(res.data) // 真正后端给的数据(res.data 才是真正的数据)
            this.name=res.data.name
            this.age=res.data.age
          })
```





### 5.4 从后端加载数据，显示电影的小案例

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
</head>
<body>
<div class="app">

    <div>
        <ul>
            <li v-for="film in filmsList">
                <h3>电影标题：{{film.name}}</h3>
                <img :src="film.poster" alt="" width="200px" height="400px">
                <p>简介：{{film.synopsis}}</p>
            </li>
        </ul>
    </div>

</div>

</body>
<script>
    var vm = new Vue({
        el: '.app',
        data: {
            filmsList: []
        },
        methods: {},
        created() {
            axios.get('http://127.0.0.1:8000/films/').then(res => {
                this.filmsList=res.data.data.films
            })
        }


    })
</script>
</html>
```



## 6 计算属性

```python
# 计算 属性：1 以后当属性用  2 只有关联的数据变化，才重新运算 3 有缓存，数据没有变化，页面再更新，它也不变化

# 案例：有个input，输入英文后，把首字母变成大写
```

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <h1>计算属性</h1>
    <!--    最简单方式-->
    <h2>最简单方法首字母变大写</h2>
    <!--    <input type="text" v-model="name">-&ndash;&gt;{{name.slice(0, 1).toUpperCase() + name.slice(1)}}-->
    <h2>使用函数实现，页面只要更新，这个函数就会重新执行,比较耗费资源</h2>
    <!--    <input type="text" v-model="name">-&ndash;&gt;{{getUpper()}}-->

    <input type="text" v-model="age">--->{{age}}

    <h3>通过计算属性实现：计算属性只有在它的相关依赖发生改变时才会重新求值</h3>
    <input type="text" v-model="name">--->{{upperName}}

</div>

</body>
<script>
    var vm = new Vue({
        el: '.app',
        data: {
            name: '',
            age: 0
        },
        methods: {
            getUpper() {
                console.log('我执行了')
                return this.name.slice(0, 1).toUpperCase() + this.name.slice(1)
            }
        },
        computed: {
            upperName() {
                console.log('我是计算属性，我执行了')
                return this.name.slice(0, 1).toUpperCase() + this.name.slice(1)
            }
        }


    })
</script>
</html>
```

### 6.2 通过计算属性，重写过滤案例

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="./js/vue.js"></script>

    <title>标题</title>

</head>
<body>


<div id="app">

    <h1>过滤案例</h1>
    <input type="text" v-model="search">
    <ul>
        <li v-for="item in newdataList">{{item}}</li>
    </ul>


</div>
</body>

<script>
    var vm = new Vue({
        el: '#app',
        data: {
            search: '',
            dataList: ['a', 'at', 'atom', 'atommon', 'be', 'beyond', 'cs', 'csrf', 'csrffe'],

        },
        // 只要input框中数据发生变化search，newdataList会重新运算，只要一运算，v-for重新循环，实现了联动
        computed:{
            newdataList(){
                return this.dataList.filter(item => {
                     return item.indexOf(this.search) > -1
                })
            }
        }
    })



</script>

</html>
```



## 7 监听属性

```python
 watch: {
            categoryType: function (val) {
                console.log('name发生了变化')
                console.log(val)
                // 向后端发送请求，请求回相应分类的数据，展示
            }
        }
  
 # 只要categoryType发送变化，就会执行对应的函数
```



```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <h1>监听属性</h1>
    <span @click="categoryType='美女'">美女</span>|
    <span @click="categoryType='帅哥'">帅哥</span>|
    <span @click="categoryType='老头'">老头</span>



    <div>
       
    </div>
</div>

</body>
<script>
    var vm = new Vue({
        el: '.app',
        data: {
            categoryType: '',
        },
        watch: {
            categoryType: function (val) {
                console.log('name发生了变化')
                console.log(val)
                // 向后端发送请求，请求回相应分类的数据，展示
            }
        }


    })
</script>
</html>
```



## 8 组件化开发基础

```python
# 作用：扩展 HTML 元素，封装可重用的代码，目的是复用
	-例如：有一个轮播，可以在很多页面中使用，一个轮播有js，css，html
	-组件把js，css，html放到一起，有逻辑，有样式，有html
  
# 多组件页面和单组件页面
	-官方推荐，以后一个组件是一个 xx.vue 文件 ---》编译
  
# Single-Page application，缩写为 SPA：以后vue项目只有一个页面，看到的页面变化都是组件间的切换


# 全局组件和局部组件

```

### 8.1 全局组件

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <h1>全局组件</h1>
    <navbar></navbar>




</div>

</body>
<script>
    // 定义一个全局组件，在任意组件中都可以使用
    var obj = {
        template: `
          <div>
          <button @click="handleBack">后退</button>
          我是一个组件-->{{name}}
          <button>前进</button>
          </div>
        `,
        data() {
            return {
                name:'lqz'
            }
        }, // 重点，data必须是个函数，返回一个对象，组件可以在多个地方重复使用，如果就是对象，导致多个组件共用同一个对象的数据，出现错乱
        methods: {
            handleBack(){
                alert('后退了')
            }
        },
        // 学的所有放在vm对象中的，都可以用
    }
    Vue.component('navbar', obj)


    var vm = new Vue({
        el: '.app',
        data: {},


    })
</script>
</html>
```



### 8.2 局部组件-->只能在某个组件中使用

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <h1>全局组件</h1>
    <navbar></navbar>
    <hr>
    <lqz></lqz>


</div>

</body>
<script>
    // 定义一个全局组件，在任意组件中都可以使用
    var obj = {
        template: `
          <div>

          <button @click="handleBack">后退</button>
          我是一个组件-->{{ name }}
          <button>前进</button>
          </div>
        `,
        data() {
            return {
                name: 'lqz'
            }
        }, // 重点，data必须是个函数，返回一个对象，组件可以在多个地方重复使用，如果就是对象，导致多个组件共用同一个对象的数据，出现错乱
        methods: {
            handleBack() {
                alert('后退了')
            }
        },
        // 学的所有放在vm对象中的，都可以用
        components: {} // 知道就可以了
    }
    Vue.component('navbar', obj)


    var vm = new Vue({
        el: '.app',
        data: {},
        components: {
            lqz: {
                template: `
                  <div>
                  <h3>我是局部组件</h3>
                  <button>点我看美女</button>
                  </div>`,
                data() {
                    return {}
                },
                methods: {}
            }
        }


    })
</script>
</html>
```



## 9 组件通信

```python
# 各个组件间，数据，方法，都是隔离的
```

### 9.1 父子通信之父传子（自定义属性）

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
<h1>通过自定义属性，实现父传子</h1>
    <h3>父组件中name:{{name}}</h3>
    <hr>
    <navbar :myname="name" :age="age"></navbar>
    <hr>

</div>

</body>
<script>
    // 定义一个全局组件，在任意组件中都可以使用

    Vue.component('navbar', {
        template: `
        <div>
        <button>前进</button>
        名字是：{{myname}}--->年龄是：{{age}}
        <button>后退</button>
        </div>`,
        props:['myname','age']
    })


    var vm = new Vue({
        el: '.app',
        data: {
            name:'彭于晏',
            age:99
        },


    })
</script>
</html>
```



### 9.2 父子通信之子传父(自定义事件)

```python
# 子组件点击按钮=>子组件执行函数this.$emit('自定义事件名字') =》注册在组件上的【自定义事件】对应的函数执行
```

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <h1>通过自定义事件，实现子传父</h1>
    <h3>父组件中收到子组件传递对值为:{{name}}</h3>
    <hr>
    <navbar @myevent="handleReceive"></navbar>
    <hr>

</div>

</body>
<script>
    Vue.component('navbar', {
        template: `
          <div>

          <input type="text" v-model="iname">---》{{ iname }}
          <br>
          <button @click="handleClick">点我吧iname传递到父组件中</button>

          </div>`,
        data() {
            return {
                iname: ''
            }
        },
        methods: {
            handleClick() {
                // 触发自定义事件的执行，并且传入当前组件中的iname
                this.$emit('myevent', this.iname)
                // alert(this.iname)
            }
        }
    })

    var vm = new Vue({
        el: '.app',
        data: {
            name: '',
        },
        methods: {
            handleReceive(iname) {
                this.name = iname
            }
        }


    })

  //子组件点击按钮=>子组件执行函数this.$emit('自定义事件名字') =》注册在组件上的【自定义事件】对应的函数执行
</script>
</html>
```



### 9.3 ref属性

```python
# 组件间通信---》通过ref属性，vue提供了一个ref属性，可以放在任意标签
	-放在普通标签,通过  this.$refs.ref对应的名字    就能拿到原生dom对象,使用原生操作该dom
  -放在自定义组件上,通过 this.$refs.ref对应的名字 就能拿到 组件对象，就可以调用对象的函数，使用对象的变量
  	-父组件中，拿到了子组件对象，对象中的属性，方法可以直接用，直接改
  
 	
  
# 通过ref，子传父
	-因为在父中，可以拿到子的对象，子对象中的所有变量，方法，都可以直接用
# 通过ref，实现父传子
	-因为在父中，可以拿到子的对象， 子对象.变量=父的变量
  

# vuex---》实现跨组件间通信
```

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <h1>ref实现组件间通信</h1>
    {{name}}<br>
    <input type="text" v-model="name" ref="myinput">
    <button @click="handleClick">点我打印</button>
    <hr>
    <navbar ref="mynavbar"></navbar>
    <hr>
    <button @click="handleClick1">点我</button>


</div>

</body>
<script>
    Vue.component('navbar', {
        template: `
          <div>
          <input type="text" v-model="iname">---》{{ iname }}
          <br>
          </div>`,
        data() {
            return {
                iname: ''
            }
        },
        methods: {
            handleClick() {
                console.log('执行了')
                return 'xxx'
            }
        }
    })
    var vm = new Vue({
        el: '.app',
        data: {
            name: '',
        },
        methods: {
            handleClick() {
                console.log(this.$refs.myinput)
                console.log(this.$refs.myinput.value)
                this.$refs.myinput.value = 'lqz is big'
                alert(this.name)
            },
            handleClick1(){
                console.log(this.$refs.mynavbar) // 相当于拿到了再组件中的this（组件对象）
                console.log(this.$refs.mynavbar.iname)
                // this.name=this.$refs.mynavbar.iname
                // 父组件中直接执行子组件的方法
                // this.$refs.mynavbar.handleClick() // 调用子组件的方法
                this.$refs.mynavbar.iname='sssss'


            }
        }


    })

</script>
</html>
```



## 10 动态组件

```python
<component> 元素，动态地绑定多个组件到它的 is 属性
<keep-alive> 保留状态，避免重新渲染

# 场景： 组件是谁不确定，通过 is 确定显示那个组件
```

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <h1>动态组件</h1>
    <ul>
        <li @click="myType='home'">首页</li>
        <li @click="myType='goods'">商品</li>
        <li @click="myType='shopping'">购物</li>
    </ul>
    <!--    动态组件，is是哪个组件名字，这里就会显示那个组件-->
    <component :is="myType"></component>


</div>

</body>
<script>

    Vue.component('home', {
        template: `
            <div>
                <h2>首页</h2>
            </div>`
    })

    Vue.component('goods', {
        template: `
            <div>
                <h2>商品</h2>
            </div>`
    })

    Vue.component('shopping', {
        template: `
            <div>
                <h2>购物</h2>
            </div>`
    })


    var vm = new Vue({
        el: '.app',
        data: {
            myType: 'home',
        },


    })

    //子组件点击按钮=>子组件执行函数this.$emit('自定义事件名字') =》注册在组件上的【自定义事件】对应的函数执行
</script>
</html>
```



### 10.1 keep-alive

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <h1>动态组件</h1>
    <ul>
        <li @click="myType='home'">首页</li>
        <li @click="myType='goods'">商品</li>
        <li @click="myType='shopping'">购物</li>
    </ul>
    <!--    动态组件，is是哪个组件名字，这里就会显示那个组件-->
    <keep-alive>
        <component :is="myType"></component>

    </keep-alive>
</div>

</body>
<script>

    Vue.component('home', {
        template: `
            <div>
                <h2>首页</h2>
            </div>`
    })

    Vue.component('goods', {
        template: `
            <div>
                <h2>商品</h2>
                要搜索的商品：<input type="text">
            </div>`
    })

    Vue.component('shopping', {
        template: `
            <div>
                <h2>购物</h2>
            </div>`
    })


    var vm = new Vue({
        el: '.app',
        data: {
            myType: 'home',
        },


    })

    //子组件点击按钮=>子组件执行函数this.$emit('自定义事件名字') =》注册在组件上的【自定义事件】对应的函数执行
</script>
</html>
```





## 11 slot插槽

### 11.1 不具名插槽

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <h1>插槽</h1>
    <hr>
    <home>
        <div>
            <img src="https://pic.maizuo.com/usr/movie/0c5874a81c7969c8eb7ddee7b6ff46b3.jpg" alt="" width="200px"
                 height="300px">
        </div>
    </home>
    <hr>

    <home>
        <div>
            我是div
        </div>
    </home>

</div>

</body>
<script>

    Vue.component('home', {
        template: `
            <div>
                <h2>首页</h2>
                <slot></slot>
            </div>`
    })

    var vm = new Vue({
        el: '.app',
        data: {
            myType: 'home',
        },
    })

</script>
</html>
```

### 11.2 具名插槽

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script src="./js/vue.js"></script>
</head>
<body>
<div class="app">
    <h1>插槽</h1>
    <hr>
    <home>
        <img src="https://pic.maizuo.com/usr/movie/0c5874a81c7969c8eb7ddee7b6ff46b3.jpg" alt="" width="200px"
             height="300px" slot="bottom">
        <div slot="top">
            我是div
        </div>
    </home>
    <hr>


</div>

</body>
<script>

    Vue.component('home', {
        template: `
            <div>
                <slot name="top"></slot>
                <p>我是子组件</p>
                <slot name="bottom"></slot>

            </div>`
    })

    var vm = new Vue({
        el: '.app',
        data: {
            myType: 'home',
        },


    })


</script>
</html>
```



## 12 Vue-CLI 项目搭建

```python
# 页面中写--》不好---》工程化---》vue是一个前端项目---》webpack支持---》vue官方提供了一个工具
# vue-cli：vue的脚手架，快速创建一个vue项目，带了很多文件
# 解释：
	vue2 中，都是使用vue-cli
  vue3中，可以使用vue-cli创建，官方更推荐使用 vite ，更块，更小
  

  
# Vue-CLI 是基于nodejs的
	-nodejs：是一门后端编程语言
  -js：前端运行在浏览器中，浏览器中有js的解释器，但是这个解释器只能运行在浏览器中，不能运行在操作系统之上
  -于是就有人，把v8引擎，让它能够运行在操作系统之上+c语言写的：文件，网络，操作系统操作的代码
  -nodejs：js语法，运行在操作系统上，后端语言
  -跟python一样，是一个解释型语言---》解释器
  
  
  -LTS：长期支持版本，https://nodejs.org/en/download/
  
# 搭建node环境
  -下载相应平台的版本
  	-一路下一步，安装即可，自动加入环境变量（在任意位置都可以执行这俩命令）
    -装完后会释放两个可执行文件
    	node：  等同于 python
      npm：   等同于 pip
      
      
      
# 安装 vue-cli：脚手架
# pip install django ---》去国外下载很慢，npm也是很慢，加速
# 【可以不用】以后使用淘宝定制的cnpm替代npm，去淘宝镜像站下载，速度块
# 执行：
npm install -g cnpm --registry=https://registry.npm.taobao.org
# 这句话执行完了，以后，就有俩可以安装第三方模块的命令  npm：慢    cnpm：块
# 以后装任何第三方模块，建议使用cnpm，但是使用npm一样的，只是速度差距
cnpm install -g @vue/cli



# 使用vue脚手架，创建vue项目，装完脚手架，就会有个  vue  命令
vue create 项目名  # 注意路径

# 使用编辑器打开创建好的项目（pycharm）

# 另一种创建项目的方式
vue ui
```

![image-20221023181641040](http://photo.liuqingzheng.top/2022%2010%2023%2018%2016%2043%20/image-20221023181641040.png)





![image-20221023181850672](http://photo.liuqingzheng.top/2022%2010%2023%2018%2018%2052%20/image-20221023181850672.png)

![image-20221023181935524](http://photo.liuqingzheng.top/2022%2010%2023%2018%2019%2037%20/image-20221023181935524.png)



![image-20221023182014441](http://photo.liuqingzheng.top/2022%2010%2023%2018%2020%2016%20/image-20221023182014441.png)

### 12.1 vue项目目录文件介绍

```python
myfirstvue  # 项目名，文件夹
  -node_modules # 当前vue项目所有的以来   python虚拟环境一样的，很大，小文件很多，可以删除
  -public      # 文件夹
    favicon.ico # 页面小图片
    index.html  # 单页面开发，就这一个index.html
  src        # 文件夹，核心代码都在这，以后，都在这里面写东西
    assets   # 静态资源：js，css，图片。。。
    components # 小组件
    router    # 装vue-router就会有它，不装就没有
    store     # 装了vuex就会有它，不装就没有
    views     # 组件，页面组件
    App.vue   # 跟组件
  main.js     # 非常重要，整个项目的入口，等同于django的managepy
  .gitignore  # git忽略文件
  babel.config.js # 语法检查，不用管
  jsconfig.json  
  package.json    # 很重要，等同于 Python项目   requirements.txt 放了项目所有的以来，不能删
  package-lock.json # 锁定依赖包，
  README.md     # 介绍
  vue.config.js # vue配置文件
```



### 12.2 vue项目启动

```python
# 方式一：
	-在命令行中敲：
  	npm run serve
    
 # 方式二：使用pycharm的点击绿色剪头执行

```

![image-20221023182558154](http://photo.liuqingzheng.top/2022%2010%2023%2018%2026%2000%20/image-20221023182558154.png)





