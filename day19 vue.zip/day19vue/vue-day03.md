

# 上节回顾

```python
# 表单控制
	-v-model绑定：双向数据绑定
	-checkbox：单选:布尔 和 多选：数组
  -radio：单选：字符串
# 购物车案例
	-v-for循环
  -插值语法： {{getprice()}}
  -js循环的几种方式：基于迭代的(in   of)，基于索引的
  	-数组.forEach()
    -jquery的$.each()
    -for (i in data){}
    -for (i of data){}
    -for(i=0;i<10;i++){}
  -checkbox的多选和单选
  -input的change事件
  -数量加减
# v-model进阶
	-lazy，number，trim
# vue声明周期
	-vue对象(vm)，vuecompoment对象(vc)
  -8个生命周期钩子函数，依次执行
  -created:有数据了，在此发送ajax请求，设置一些定时任务
  -destroyed：资源请理性的工作（清空定时器）
  -定时任务，延迟任务
  	setInterval
    setTimeout
# 前后端交互之jq的ajax
	-jquery的ajax
  $.ajax({
    url:'http://127.0.0.1/film', # 后端使用dajngo写的，会有跨域问题
    type:'get',
    success:function(data){
      
    }
  })
# fetch和axios发送请求
	-早期，js发送ajax使用内置的：XMLHttpRequest，浏览器兼容性不好，用起来麻烦
  -jquery，对它进行封装---》$.ajax
  -fetch：以后都是用它发送ajax请求，不支持ie浏览器
  -第三方axios，vue中常用  aixos.get()
  	 axios.get('http://127.0.0.1:8000/test/').then(res=>{})
  -箭头函数：
  var f=()=>{}
  var f= item=>{}
  var f=        item=>'lqz'
    
    
    
# 显示电影小案例
	-后端配合接口
  -前端在created中拿到数据，渲染页面v-for
  
  
  -前后端交互，有编码格式
    -前后端交互，携带的数据放在http请求体(body中)，有三种编码格式
    
  	-urlencoded：form表单提交默认的格式，ajax提交默认格式
    	-name=lqz&age=19
    -json:前后端分离项目常用的格式
    	{"name":"lqz","age":19}
      
      request.data
      原生django中，request.POST 只能取出urlencoded编码的数据，json格式的取不出来
    -form-data：上传文件使用这种格式
    
   -axios发送get请求
  		axios.post(url)
  -axios发送post请求
  	axios.post(url,{name:'lqz',age:19})
    axios.post(url,json.stringify({name:'lqz',age:19}))
    
  -axios发送请求，请求头中带数据（jwt，认证session）
  axios.post(url, data, {
                            headers: {
                                'token':'asdfads'
                            }
                        })
    
# 计算属性
	-插值写函数，页面只要刷新，函数会重新运算，耗费资源
  -computed:{
    fullName(){}
  }
  -缓存，直接把  fullName  当变量用
  
# 监听属性
	-只要数据发送变化，就会触发某个函数的执行
  watch:{
    name(){
      只要data中name发生变化，这个函数就会执行
    }
  }
# 局部和全局组件的定义
	-组件有自己的html，css，js，生命周期，data，methods，watch，computed
# 自定义属性实现父传子
	-写在标签上自定义的属性
  -在组件中使用props接收
# 自定义事件实现子传父
	-自定义事件实现子传父
  -this.$emit(事件名)
# ref属性实现组件间通信
	-vue提供的写在标签上的ref属性
  -放在普通标签，放在组件上
  
# 动态组件
	-component标签通过is决定显示的组件是什么
# 插槽的使用
	-在组件中留空白，在父组件中使用时，插入html片段
  -默认插槽，具名插槽
#  vue-cli创建项目并启动
#  vue项目目录介绍
```



# 今日内容

## 0 vue项目目录介绍和编写技巧

### 1 vue-cli创建vue项目

```python
# 之前全是在 单个html中写vue的语法
# 做成一个vue项目，使用编辑器打开
# vue-cli 脚手架，帮助咱们创建vue项目(webpack打包)--》就像咱们通过django-admin创建django项目一样

# 安装nodejs的环境，解释型后端语言（对比安装python环境即可）
		-node 命令     等同于python
    -npm 命令      等同于pip，安装第三方模块使用它,去国外下载，速度慢
    -cnpm 命令加速，以后会去淘宝镜像下载，速度很快  
    npm install -g cnpm --registry=https://registry.npm.taobao.org
    
    
# 安装vue-cli
npm install -g @vue/cli    # 等同于 pip install django
# 释放出一个命令  vue        # 装完django释放一个命令， django-admin
# 使用vue命令创建vue项目     # 使用django-admin创建django项目
 @vue/cli 5.0.8           # 查看版本
 vue create 项目名        # django-admin startproject 项目名
 
 # 另一种方式创建项目(图形化的创建)
 vue ui
  
  
# 解释
vue-cli:很多年前，vue的脚手架叫这个名字，安装 npm install vue-cli
@vue/cli：新的 npm install @vue/cli
如果装了vue-cli，需要先卸载  npm uninstall vue-cli,再装新的 npm install @vue/cli



# 使用编辑器打开项目，运行项目
	-方式一：在命令行执行：npm run serve  # python3 manage.py runserver
  -方式二：在pychrm中快速执行,配置，点击绿色箭头执行
```



### 2 vue目录结构

```python
vue2_test         # 项目名
  node_modules # 类似于学的python的虚拟环境，主要放了，当前项目所有的以来，很多小文件，给别人发送项目需要把它删掉，如果删掉，执行命令  npm install  重新下载
  public         # 文件夹
    favicon.ico  # 网站小图标
    index.html   # 单页面应用(spa) <div id="app"></div>
  src            # 重点：文件夹，以后咱们的代码，都写在这里，js，组件，启动文件。。。
    assets       # 文件夹，放静态资源，图片，js，css
    	logo.png   # 图片
    components   # 文件夹，内部放所有的小组件，非页面组件
    	HelloWorld.vue # 写了一个默认的HelloWorld的组件，是以 .vue结尾都
    router       # 文件夹，vue-router模块安装了就会有，主要做路由配置
    	index.js   # vue-router的js文件
    store        #  文件夹，vuex模块安装了就会有，主要做vuex的配置
    	index.js   # vuex的js文件
    views        # 文件夹，放组件，放页面组件
    	AboutView.vue # 关于的页面组件
    	HomeView.vue  # 首页的页面组件
    App.vue      # 根组件 vm对象就是它，它管理了index.html的id为app的div
    main.js      # 整个入口，非常重要，很多全局配置。。。
  .gitignore     # git忽略文件相关
  babel.config.js# babel的配置，咱们不用管
  jsconfig.json  # 不需要关注
  package.json   # 重要：项目依赖的所有第三方模块 等同于python中  requirements.txt
  							 # 执行了 npm install -S axios,这里面就会多这一条
  package-lock.json # 锁定版本
  README.md      # 项目介绍
  vue.config.js  # vue的配置文件  等同于 django中setting.py
```



### 3 vue项目开发技巧

```python
# 以后组件化开发，就是写一个个的组件：页面组件，小组件

# App.vue :根组件

# 以后就是写组件，组件就是  xx.vue
## 第一部分
<template>
  <div id="app">  # 组件必须套在一个标签内部，之前咱们用反引号写的html内容
  </div>
</template>

## 第二部分：
<script>
export default {
  # 以后在这个对象中写咱们之前学的data，methods，watch，computed，生命周期钩子
  name: 'App',
  data() {
    return {
      name: 'lqz'
    }
  },
  methods: {
    handleClick() {
      this.name = '彭于晏'
    }

  }
}
</script>

## 第三部分：这里面写样式
<style>
h1 {
  background-color: red;
}
</style>




# 使用步骤

##1  以后，只要创建组件  HelloWorld.vue
<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    x的值是：{{x}},y的值是：{{y}}
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: ['msg'],  # 父传子，自定义属性，接受
  data(){
    return {
      x:10,
      y:20
    }
  }
}
</script>



## 2 在根组件App.vue 中使用这个组件
<template>
  <div id="app">
    <h1>我是h1</h1>
    {{ name }}
    <br>
    <button @click="handleClick">点我名字变化</button>
    <hr>
    <HelloWorld :msg="msg"></HelloWorld>  # 自定义属性实现父传子
  </div>
</template>

<style>
h1 {
  background-color: red;
}
</style>

<script>
// 把HelloWorld组件导入
import HelloWorld from "@/components/HelloWorld.vue";
export default {
  name: 'App',
  data() {
    return {
      name: 'lqz',
      msg:'你好啊'
    }
  },
  methods: {
    handleClick() {
      this.name = '彭于晏'
    }

  },
  components:{ # 注册局部组件
    HelloWorld
  }
}
</script>

```



## 1 es6导入导出语法

```python
# 写vue项目，大量的看到：他们是es6的导入和导出语法
		import App from './App.vue'
		export default{}
    
# 总结：
	1 以后可以在任意位置写xx.js,可以定义变量，定义函数
  2 导出某些变量，函数
   export default {
     name,print
   }
    
   2.1 默认导出和命名导出
  #默认导出   不用名名字
	export default {}
	# 命名导出
  export const a =10
    
  3 在想用的地方导入
  	import 别名  form '路径'  # . 和 ..
  4 使用
    别名.name
    别名.print()
    
    

    
 # 补充：如果一个包下有一个名为index.js 的文件，可以只导入到包这一层
import lqz from './lqz' #  简写成，index.js 可以省略，以后看到的index.js 等同于python的包中的__init__.py
lqz.showName()
```



## 2 axios与后端交互处理跨域，携带数据，携带请求头

### 2.1 使用axios与后端交互

```python
# 1 安装
npm install -S axios
# 2 在想用的地方导入使用即可
import axios from 'axios'
# 3 使用发送请求即可
  axios.get('http://127.0.0.1:8000/user/').then(res=>{
        console.log(res)
        this.name=res.data.name
        this.age=res.data.age
      })


# 解决跨域很多种：浏览器的同源策略
	-1 后端使用cors技术
  -2 使用nginx转发
  -3 前端做代理：之上测试阶段使用，上线后没有
```

### 2.2 处理跨域

```python
# 1  django中使用django-cors-headers，解决跨域
# 2 安装 pip3 install django-cors-headers
# 3 在app的注册中加入
INSTALLED_APPS = (
	...
	'corsheaders',
	...
)
# 4 在中间件中加入
MIDDLEWARE = [ 
	...
	'corsheaders.middleware.CorsMiddleware',
	...
]

# 5 配置文件中加入
CORS_ALLOW_CREDENTIALS = True
CORS_ORIGIN_ALLOW_ALL = True
CORS_ORIGIN_WHITELIST = (
	'*'
)
CORS_ALLOW_METHODS = (
	'DELETE',
	'GET',
	'OPTIONS',
	'PATCH',
	'POST',
	'PUT',
	'VIEW',
)

CORS_ALLOW_HEADERS = (
	'XMLHttpRequest',
	'X_FILENAME',
	'accept-encoding',
	'authorization',
	'content-type',
	'dnt',
	'origin',
	'user-agent',
	'x-csrftoken',
	'x-requested-with',
	'Pragma',
)
```



### 2.3 post请求携带数据

```js
handleSubmit() {
      axios.post('http://127.0.0.1:8000/user/', {
        username: this.username,
        password: this.password
      }).then(res => {
        console.log(res.data)
        if (res.data.code == 100) {
          // 登录成功跳转到百度
          location.href = 'http://www.baidu.com'
        } else {
          alert(res.data.msg)
        }
      })
    }
```



### 2.4 携带请求头

```python
# 请求头中带token

handleSubmit1() {
      axios.post('http://127.0.0.1:8000/user/',
          {
            username: this.username,
            password: this.password
          },
          {
            headers: {token: 'asdfasdfasd'}
          }
      ).then(res => {
        console.log(res.data)
        if (res.data.code == 100) {
          // 登录成功跳转到百度
          location.href = 'http://www.baidu.com'
        } else {
          alert(res.data.msg)
        }
      })
    }
```



## 

## 3 props配置项指定默认值

```python
# props是组件间通信，父传子，自定义属性时，子组件间中接收父组件中传入的数据使用的配置项
# 三种使用方式
```

```js
 //1 基本使用
  // props: ['msg'],
  // 2 属性认证，限制类型
  // props:{
  //   msg:String  // 接受的msg必须是string类型
  // },
  // 3 限定类型，限定必传，限定默认值
  props: {
    msg: {
      type: String, //类型
      required: false, //必要性
      default: '老王' //默认值
    },
    xx:Boolean,
  },
```



## 4 混入

```python
# minxin 混入：可以把多个组件共用的配置提取成一个混入对象

# 提取混入对象
1 第一步：抽取共用的代码，定义混入  mixin的index.js下写了
export const hunhe = {
    methods: {
        handleShowName() {
            alert(this.name)
        }
    },
}

2 第二步：注册混入，全局注册（只要注册了，所有组件都可以用）
// 全局注册混入,以后所有组件中都能用
import {hunhe} from '@/mixin'
Vue.mixin(hunhe)

3 第三步：注册混入，局部注册，在组件中注册了，这个组件可以用(在组件中)
import {hunhe} from "@/mixin";
mixins: [hunhe]
```



## 5 插件

```python
# 插件功能：用于增强Vue，后期咱们学的vuex，vue-router，elementui都是基于插件的形式使用的

# 实现一个插件
1 定义一个插件，插件内部加入混入
import Vue from 'vue'
export default {
    install(a) {
        console.log(a)
        // 写代码，加入混入
        Vue.mixin({
            methods: {
                handleShowName() {
                    alert(this.name)
                }
            }
        })
    

    }
}


2 应用插件  在main.js中
import plugins from './plugins'
Vue.use(plugins) // 自动调用插件内的install，完成对Vue的强化

```



## 6 scoped样式

```python
# 加载<style scoped> 表示写的样式，只在当前组件生效，不会影响到其他组件，造成污染
```



## 7 命名插槽的其他写法

```python
# 1 默认插槽
# 2 具名插槽
# 3 使用v-slot:bottom指定命名插槽  建议使用这个
  <template v-slot:bottom>
        <form action="" >
          <p>用户名：<input type="text"></p>
          <p>密码：<input type="password"></p>
          <button>登录</button>
        </form>
        <p>我是p标签</p>
  </template>

```



## 8 项目中使用bootstrap，elementui

```python
# 样子不好看，css用的少，ui组件库
# 使用bootstrap，vue不建议使用，可以用，建议用elementui，饿了么团队出的ui组件库
# 除了这个外，还有很多
	-iView：https://www.iviewui.com/view-ui-plus/guide/introduce
  -app端的ui组件库：http://vant3.uihtm.com/#/zh-CN/home
  -很多其他
# elementui
```

### 8.1 elementui的使用步骤

```python
#  1 安装   npm install element-ui -S

# 2 在main.js中引入
// 使用elemenui
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
Vue.use(ElementUI);  // 使用插件，多出很多ui组件，全局的


# 3 在组件中使用，直接去官网复制代码，贴进去即可
	注意复制全：templage，script，style内容
```



### 8.2 boostrap

```python
# 1 安装
npm install jquery
npm install bootstrap@3

# 2 在main.js中引入
import 'bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css'

# 3 使用jquery,在vue的配置文件中vue.config.js
const {defineConfig} = require('@vue/cli-service')
const webpack = require("webpack");
module.exports = {
    configureWebpack: {
        plugins: [
            new webpack.ProvidePlugin({
                $: "jquery",
                jQuery: "jquery",
                "window.jQuery": "jquery",
                "window.$": "jquery",
                Popper: ["popper.js", "default"]
            })
        ]
    }
};


# 4 以后在组件中直接使用bootsrtap的样式即可

```



## 9 localStorage和sessionStorage

```python
# 前端存数据的地方
	-cookie中：借助第三方插件，自己用js写
  -sessionStorage：关闭浏览器，它就没了
  -localStorage：永久存在，手动删除，或浏览器存满了、
# 通过这三个东西就可以实现组件间通信


# 使用：sessionStorage
sessionStorage.setItem('name', 'lqz')
sessionStorage.getItem('name')
sessionStorage.clear()  // 清空
sessionStorage.removeItem('name')

# 使用：localStorage
localStorage.setItem('name', 'lqz')
localStorage.getItem('name')
localStorage.clear()  // 清空
localStorage.removeItem('name')
```



## 10 vuex的使用

```python
# 插件：vuex，状态管理器，存取数据用的,可以跨组件通信（屏蔽了组件的父子关系）

# 使用
1 新建store/index.js
import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)
export default new Vuex.Store({
    // 存数据的地方
    state: {
        sum: 0
    },
    // 厨师，真正的干货
    mutations: {
        JIA(state, value) {
            state.sum += value
        }
    },
    // 服务员，中转站
    actions: {
        jia(context, value) {
            // context 上下文
            // value 组件中调用时，传入的值
            // 判断是否有权限改请求一下后端接口，获取了，有权限，
            context.commit('JIA', value)

        }
    },
})

2 在main.js中使用
import store from './store'
new Vue({
    router,
    store,  # 把store放在这里
    render: h => h(App)
}).$mount('#app')

3 在任意组件中，想获取state中的数据
	this.$store.state.变量  即可
  
4 在任意组件中修改数据
this.$store.dispatch("actions中定义的函数",参数)
它就会触发  actions中定义的函数  的执行，内部执行了 context.commit('JIA', value)
它又会触发  mutations中定义的函数执行，内部对sum进行了修改


5 在任意组件中修改数据也可以
this.$store.commit('JIA',2)

```





![image-20221030173226319](http://photo.liuqingzheng.top/2022%2010%2030%2017%2032%2031%20/image-20221030173226319.png)

## 11 vue-router使用

```python
# spa:单页面应用，很多页面组件，来回切换，借助于vue-router

# 使用
1 router下新建index.js
import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '@/views/Home'

Vue.use(VueRouter)


// 这个地方注册路由,最重要的地方
const routes = [
    {
    path: '/home',
    name: 'home',
    component: Home
  },
    {
    path: '/about',
    name: 'about',
    component: About
  },
    {
    path: '/login',
    name: 'login',
    component: Login
  },
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router

2 在main.js中注册
import router from './router'
new Vue({
    router,
    render: h => h(App)
}).$mount('#app')


3 写好一个个页面组件
 Home.vue
 About.vue
 Login.vue
  
  
4 以后访问路径
http://192.168.1.5:8080/home   显示Home组件
http://192.168.1.5:8080/about  显示About组件
http://192.168.1.5:8080/login  显示Login组件




5 以后在任意组件中
	this.$router,拿到的就是导出的router对象

```

![image-20221030173939752](http://photo.liuqingzheng.top/2022%2010%2030%2017%2039%2041%20/image-20221030173939752.png)

## 12 Vue3介绍

```python
# vue3 比 vue2好，性能提高了，支持ts语法，源码升级，多个一些新的api
# 重点：
	组合式API(vue3)   和  配置项API（vue2）
  
  
  
# 学的所有vue2的东西，可以直接写在vue3上，完全支持
  
```



## 13 Vue3 项目创建

```python
# 创建vue3的项目
	-方式一：使用vue-cli创建
  	-跟创建vue2一模一样
  -方式二：使用vite创建(不需要装任何东西)
    ## 创建工程
    npm init vite-app vue3_test2
    ## 进入工程目录
    cd vue3_test2
    ## 安装依赖
    npm install
    ## 运行
    npm run dev
```



## 14 常用api之setup

```python
# setup 中可以写变量，写函数，只要reurn了，在模版中就可以使用
```



```js
setup() {
    // 定义变量  const不能改 let 跟var一样
    let name = 'lqz'
    let age = 19  //
    // 定义函数
    function handleAdd(){
      age=age+1    // 数据变了，页面没变
      console.log(age)
    }
    // 要在模版中使用必须，return出去
    return {name,age,handleAdd}
  }
```



## 15 常用api之ref和reactive

```python
# 上面没有响应式：数据变，页面变，页面变数据变

# 基本数据类型使用ref包裹一下，使之变成响应式
在模版中直接使用
在setup中 使用对象.value获取真正的值

# 对象，数组类型，使用reactive包裹
模版中直接使用

```



## 16 计算和监听属性

```python
# computed 配置项完成计算属性
# watch    配置项完成监听属性
以上的照常用

# 推荐使用组合式api
```



## 17 生命周期

```python
# 生命周期变了
vue2 8个生命周期钩子函数
vue3 8个生命周期钩子函数，支持组合式api
    beforeCreate===>setup()
    created=======>setup()
    beforeMount ===>onBeforeMount
    mounted=======>onMounted
    beforeUpdate===>onBeforeUpdate
    updated =======>onUpdated
    ------下面的变了------
    beforeUnmount ==>onBeforeUnmount
    unmounted =====>onUnmounted

```



## 18  toRef

```python
  setup() {

    const data = reactive({
      name: '刘',
      age: '清政',
      isShow:false
    })



    // es6语法中的对象解压
    return {
      ...toRefs(data)  // 解压开，return了
      // name:data.name,
      // age:data.age,
      // isShow:data.isShow,
    }
  }
```





## 

