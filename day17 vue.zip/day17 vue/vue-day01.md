

![刘清政个人介绍](http://photo.liuqingzheng.top/2022%2010%2016%2008%2055%2010%20/%E5%88%98%E6%B8%85%E6%94%BF%E4%B8%AA%E4%BA%BA%E4%BB%8B%E7%BB%8D.jpeg)

```python
微信：306334678  备注名字+从哪里来的
```

# 今日内容

## 1 Vue介绍

### 1.1 前端发展历史

```python
# 1 html(5),css(3),javascript=(ECMA:5，补充es6语法,最新:13，bom:浏览器对象,dom:文档对象)--》编写一个个的页面 -> 给后端(PHP、Python、Go、Java) -> 后端嵌入模板语法(dtl:django的模版语法 xx.html ) -> 后端渲染完数据 -> 返回数据给前端 -> 在浏览器中查看
		-剪头函数，模块导入，let
  	-python ：3.11----》3.8 , 3.9
    -java   ：java19，公司大量的用 java8 1.8 
    -模版语法：django：模版语法， index.html ---》写了python语法 {%  %}---》模版语法
    	-模版语法写好----》python解释器负责把python语法解析完转成 纯粹的html，css，js
   
  
# 2 Ajax的出现 -> 后台发送异步请求，Render+Ajax混合

# 3 单用Ajax（加载数据，DOM渲染页面）：前后端分离的雏形

# 4 Angular框架的出现（1个JS框架）：出现了“前端工程化”的概念（前端也是1个工程、1个项目）：笨重，越来越少的人用了

# 5 React、Vue框架：当下最火的2个前端框架（Vue：国人写的，国人喜欢用，中小厂，全栈工程师，React：外国人喜欢用，大厂喜欢用）

# 6 移动开发（Android+IOS） + Web（Web+微信小程序+支付宝小程序） + 桌面开发（Windows桌面）：前端 -> 大前端

# 7 可不可以一套编码，多端运行 ：一套代码在各个平台运行（大前端）：谷歌Flutter平台（Dart语言：和Java很像）可以运行在IOS、Android、PC端，桌面端支持不好---》部分公司在用，坑比较多

# 8 在Vue框架的基础性上 uni-app：一套编码 编到10个平台----》学习vue的性价比很高

# 9 在不久的将来 ，前端框架可能会一统天下
 
  
 
# ts和es：
	typescript：微软出的脚本语言，强类型，微软开发的一个开源的编程语言，通过在JavaScript的基础上添加静态类型定义构建而成
  ecma：标准---》js语言，弱类型
  typescript是js的超集
  写前端可以使用js，也可以使用ts，ts兼容js的
  js：历史遗留了很多坑
  
  # 我感觉会
  
html,css,js--->PC端(网页)，移动端（安卓，ios）,小程序(微信官方:标签是html5内容)
```

![image-20221016094526430](http://photo.liuqingzheng.top/2022%2010%2016%2009%2045%2028%20/image-20221016094526430.png)

![image-20221016094955593](http://photo.liuqingzheng.top/2022%2010%2016%2009%2049%2057%20/image-20221016094955593.png)





### 1.2 Vue介绍

```python
# Vue (读音 /vjuː/，类似于 view)--->1 js框架(jquery)--->2 渐进式框架(单个页面使用vue，整个项目都使用vue)
是一套用于构建用户界面的渐进式框架
与其它大型框架不同的是，Vue 被设计为可以自底向上逐层应用
Vue 的核心库只关注视图层，不仅易于上手，还便于与第三方库或既有项目整合

# 官网：https://cn.vuejs.org/

#	Vue 版本问题：两个版本（些许差距，基础都是一样的）
	-2.x版本：老版本
  -3.x版本：完整支持ts语法,2020年---》
  -vue： 正处于转型期，大量公司还在用vue3，少量公司在用vue3

# 特点
	-通过 HTML、CSS、JavaScript构建应用--》要有这些东西基础
  -不断繁荣的生态系统，可以在一个库和一套完整框架之间自如伸缩
  -20kB min+gzip    运行大小    超快虚拟 DOM    最省心的优化
  
  
# M-V-VM思想
	-django:MTV   mvc架构
  -MVP：移动端会使用
  -Vue：M-V-VM 架构---》js的变量---》写到dom(文档)中
  	-Model ：vue对象的data属性里面的数据，这里的数据要显示到页面中，js里面有变量
		-View ：vue中数据要显示的HTML页面，在vue中，也称之为“视图模板” （HTML+CSS）
		-ViewModel：vue中编写代码时的vm对象，它是vue.js的核心，负责连接 View 和 Model数据的中转，保证视图和数据的一致性，所以前面代码中，data里面的数据被显示中p标签中就是vm对象自动完成的（双向数据绑定：JS中变量变了，HTML中数据也跟着改变）
    
  -以后不需要咱们操作dom了---》因为有vm这层---》jquery选择器，元生js 完全用不到了---》jq已经完成自己的历史使命了，慢慢退出舞台了
  
  

  
# 组件化开发、单页面开发
	-组件化开发：把某些可能会多次使用的 htm，css，js，写成单独的，以后直接引入即可
  	
  -单页面开发：如果是vue项目，整个项目其实就一个 index.html 页面
  	-以后都是只有一个index.html 看到的页面变化，不是多个html页面在变化，而是组件的替换
    
    
```



![image-20221016103403145](http://photo.liuqingzheng.top/2022%2010%2016%2010%2034%2004%20/image-20221016103403145.png)





## 2 Vue的快速使用

```python
# 补充：工欲善其事必先利其器---》咱们要开发vue，需要有一个比较趁手 集成开发工具(IDE)
	-vscode:微软出的，不仅可以写前端，还可以写python,go.....  免费的
  -Jetbrains捷克的公司公司出的：全家桶：pycharm，goland，IDEA(java)，phpstorm，webstorm(前端)。。。
  	-收费，挺贵  全家桶的授权：599刀一年  单版本授权 199刀 一年
    -破解：pycharm本身跟webstorm师出同门
    -直接使用Pycharm---》vue的插件，就可以写vue了----》讲课用，不需要再多下一个编辑器
    -直接下载webstorm--》破解方案跟pycharm完全一样
    
# 使用Pycharm开发---》下载后有vue代码提示，不下也能开发vue
    -新建一个项目（python项目也可以）
  	-装一个vue的插件：setting中搜plugins---》vue---》安装---》ok---》apply

# Vue 就是一个js框架----》把源代码下载下来(cdn)，引入到页面中去
	-先用vue2的讲：基础内容是一样的
  -拿到vue2的源码，放在咱们工程中--》js文件夹下vue.js

	-渐进式框架---》在一个html中使用vue---》跟之前使用jq是一模一样


```

![image-20221016105736247](http://photo.liuqingzheng.top/2022%2010%2016%2010%2057%2037%20/image-20221016105736247.png)

### 第一个vue项目

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- 引入vue,跟之前引入jquery是一样的-->
    <script src="./js/vue.js"></script>
    <title>标题</title>
</head>
<body>

<div id="app">
    <!--以后在这div内部，就可以写vue的语法了,插值语法，把变量放在{{}}内，它就会把变量渲染在这-->
    <h1>{{name}}</h1>
</div>
</body>

<script>
    // 写js代码,new 得到一个vue对象,传入配置项，传入一个对象，有key，有value
    new Vue({
        el: '#app', // 根据id 找到div，这个div就被vue托管了，以后div中就可以写vue的语法了
        data: {
            name: 'lqz'  // 定义了一个变量 name
        }
    })

</script>

</html>
```



## 3 模版语法

```python

# json 格式：字符串   {"name":"lqz","age":19}
	-python  js 都支持---》字符串

# python 中字典      {'name':'lqz','age':19}
# js 对象(一般不叫字典) {name:"lqz",age:19}

# {{变量，函数，短的表达式}}
```



### 3.1 代码

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="./js/vue.js"></script>
    <title>标题</title>
</head>
<body>

<div id="app">
    <h1>渲染变量</h1>
    <p>我的名字:{{name}}</p>
    <p>我的年龄:{{age}}</p>
    <p>数组:{{l}}</p>
    <p>数组取值:{{l[1]}}</p>
    <p>对象:{{obj}}</p>
    <p>对象取值:{{obj['age']}}</p>
    <p>对象取值:{{obj.name}}</p>
    <p>标签：{{s}}</p>
    <h1>渲染函数--后面讲</h1>

    <h1>渲染表达式：三目运算符,一定不要写太长</h1>
    <p>{{age > 20 ? '男人' : '男孩'}}</p>
    <p>{{age == 19}}</p>


</div>
</body>

<script>
    new Vue({
        el: '#app',
        data: {
            name: 'lqz',
            age: 19,
            l: [1, 2, 3], // js中叫数组，python中叫列表
            obj: {name: '彭于晏', age: 40},  // js中叫对象，python中叫字典  对象取值不加引号表示变量
            s: '<input type="text">',
            t: 10 > 9 ? '大于' : '小于'  // 跟python中的三元表达式是一样的  t= 条件 ? '符合条件':'不符合'
            // t:'大于'

        }
    })

</script>

</html>
```



## 4 指令

```python
# vue中有很多指令，放在标签上,以v-开头的，称之为指令，每个指令都能完成相应操作
<p v-html='js变量，函数，表达式'> </p>
```



### 4.1 文本指令（操作文本相关）

```python
# v-html:把变量的内容当html渲染到标签中去（字符串是标签，会完整渲染）

# v-text:把变量内容当字符串写到到标签中（字符串是标签，不会渲染成标签），如果原来标签有内容，会去掉
	-可以完成跟 {{}} 一样的功能，但是还是不一样的

# v-show：只能跟 true  或 false  或   表达式运算结果是布尔类型，控制标签的显示与否
		-
# v-if ：只能跟 true  或 false  或   表达式运算结果是布尔类型，控制标签的显示与否

# vue中面试题：v-if和v-show区别是什么？
	-v-if:如果是false，不显示，标签也不存在（删除和添加标签，效率低）
  -v-show,如果是false，不显示，但是标签存在，只是通过样式 dispaly=none控制的
```

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="./js/vue.js"></script>
    <title>标题</title>
</head>
<body>


<div id="app">
    <h1>v-html</h1>
    <p>{{s}}</p>
    <p v-html="s"></p>
    <div v-html="s"></div>
    <h1>v-test</h1>
    <p v-text="s">美女</p>
    <h1>v-show和v-if</h1>

    <div v-show="b2">美女</div>
    <div v-if="b1">帅哥</div>

</div>
</body>

<script>
    new Vue({
        el: '#app',
        data: {
            s: '<input type="text">',
            b1: true,
            b2: false


        }
    })

</script>

</html>
```



### 补充小知识：MVVM：model的数据变，view也跟着变；只要view变化，model也跟着变化

```python

# 双向数据绑定

# 把new Vue后的对象赋值给变量vm
  var vm = new Vue({
          el: '#app',
          data: {
              s: '<input type="text">',
              b1: true,
              b2: false
          }
      })
  
# 以后从vm中可以通过 vm._data 取到 实例化的时候的data
# 以后也可以从vm.变量名取到data中的变量
  
  
# 在控制台修改变量的值，页面会立马跟着变化 ---》以后只需要修改变量值即可，不需要操作dom了



# 就是后台变 或者数据库的数据变化，前端就变？不是
```

![image-20221016142247104](http://photo.liuqingzheng.top/2022%2010%2016%2014%2022%2049%20/image-20221016142247104.png)



### 4.2 事件指令

```python
# v-xx 放在标签中就是指令，指令就能完成不同的功能
# v-on:事件名='函数'    ： 给这个标签绑定一个事件，当触发这个事件，就会执行函数
		-事件：click，blur，dbclick。。。很多
    -函数 必须写在methods 对象内，可以使用es6的对象写法
# 重点：
v-on:事件名='函数'    可以简写成      @事件名='函数'（以后都用它）




# 补充
	-html：标签
  -css：样式（好看）  bootstrap是css样式，element-ui
  -js：动起来        jquery是js框架，vue是js框架，react
```

#### 代码

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href="https://cdn.bootcss.com/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

    <script src="./js/vue.js"></script>
    <title>标题</title>
</head>
<body>


<div id="app">

<!--    <button class="btn btn-danger" v-on:click="handleClick">点我看美女</button>-->
    <button class="btn btn-danger"  @click="handleClick">点我看美女2</button>
    <br>



<!--    写个按钮，一点击就显示美女图片，再点击一次就不显示了-->
    <button @click="handleShow">看我美女显示和消失</button>
    <br>
<!--    <img v-show="zs" src="https://tva1.sinaimg.cn/large/00831rSTly1gd1u0jw182j30u00u043b.jpg" alt="" height="500px" width="500px">-->
    <img v-if="zs" src="https://tva1.sinaimg.cn/large/00831rSTly1gd1u0jw182j30u00u043b.jpg" alt="" height="500px" width="500px">

</div>
</body>

<script>
    var vm = new Vue({
        el: '#app',
        data: {
            zs:true,
        },   // 变量写在这里
        methods: {
            // 方式一：es5的语法
            // handleClick: function () {
            //     alert('美女')
            // }
            // 方式二：常用的，es6的语法
            handleClick() {
                alert('美女')
            },
            handleShow(){
                // 修改show的值为  !show
                // this代指的是vm对象，Vue对象
                this.zs=!this.zs

            }

        }, // 函数写在这里
    })


    // es6 语法的对象写法
    // var obj = {'name': 'lqz', 'age': 19}
    // var obj1 = {name: 'lqz', age: 19}
    //
    // name = 'lqz'
    // age = 19
    // var onj2 = {name, age}  // 等同于{name: 'lqz', age: 19}  es6 对象写法

</script>

</html>
```



### 4.3 属性指令

```python
# v-bind:属性名="变量"
	-标签会有很多属性 <a href=""></a>   <img src="" >  <p name="xxx"></p> <button class="btn">点我</button>
  -可以绑定标签的任意属性
  -v-bind可以简写成 : -----> :属性='变量'
```



```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="./js/vue.js"></script>
    <title>标题</title>
</head>
<body>


<div id="app">

    <!--    <img v-bind:src="url" alt="">-->

    <h1>点我随机弹美女图片</h1>
    <button @click="handleClick">点我</button>
    <br>
<!--    <img v-bind:src="url" alt="" width="500px" height="500px">-->
    <img :src="url" alt="" width="500px" height="500px">


</div>
</body>

<script>
    var vm = new Vue({
        el: '#app',
        data: {
            url: 'https://tva1.sinaimg.cn/large/00831rSTly1gd1u0jw182j30u00u043b.jpg',
            l: ['https://img2.woyaogexing.com/2022/10/13/05e406595e217e0c!400x400.jpg',
                'https://img2.woyaogexing.com/2022/10/13/c03408591b068c18!400x400.jpg',
                'https://img2.woyaogexing.com/2022/10/13/f810d999375f7f1c!400x400.jpg']
        },
        methods: {
            handleClick() {
                // 随机从生成0--3的数字
                this.url = this.l[Math.floor(Math.random()*3)];
            }
        }
    })

</script>

</html>
```



## 5 style和class

```python
# 属性指令：style和class属性特殊一点


#  // class属性可以绑定：字符串，数组(常用，class由多个类组成，数组跟它最搭)，对象
#  // style 属性可以绑定： 字符串，数组，对象(常用)
```



```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="./js/vue.js"></script>
    <title>标题</title>
    <style>
        .red {
            color: crimson;
        }

        .back {
            background: greenyellow;
        }

        .size {
            font-size: 50px;
        }

    </style>
</head>
<body>


<div id="app">
    <h1>class的三种绑定方式</h1>
    <!--    <div :class="class_str">-->
    <!--    <div :class="class_list">-->
    <div :class="class_obj">
        我是一个div
    </div>

    <hr>
    <h1>style的三种绑定方式</h1>
    <!--    <div style="font-size: 50px;background: pink;color: green">-->
    <!--    <div :style="style_str">-->
    <!--    <div :style="style_list">-->
    <div :style="style_obj">
        我是第二个div
    </div>

</div>
</body>

<script>
    var vm = new Vue({
        el: '#app',
        data: {
            // class:字符串，数组(常用，class由多个类组成，数组跟它最搭)，对象
            class_str: 'red size',
            class_list: ['red', 'size'], // 如果咱么向数组末尾最近一个类名，div样式就变了
            class_obj: {red: true, size: false, back: false},
            // style :字符串，数组，对象
            style_str: 'font-size: 50px;background: pink',
            style_list: [{'font-size': '50px'}, {'background': 'pink'}, {'color': 'green'}],
            // style_list: [{fontSize: '50px'}, {background: 'pink'}, {color: 'green'}], // 跟上面一样，如果是 - 相连的两个单词可以改成驼峰形式
            style_obj: {fontSize: '50px', background: 'pink', color: 'green'}, // style 来讲，它用的多
        },
        methods: {}
    })

</script>

</html>
```

## 6 条件渲染

```python
# 指令：实现符合某个条件，就显示某个标签
v-if  v-else-if   v-else

# 
```

### 6.1 条件渲染

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="./js/vue.js"></script>
    <title>标题</title>
    <style>


    </style>
</head>
<body>


<div id="app">

    <p v-if="score>90">优秀</p>
    <p v-else-if="score>70 && score<=90">良好</p>
    <p v-else-if="score>60 && score<=70">及格</p>
    <p v-else>不及格</p>

</div>
</body>

<script>
    var vm = new Vue({
        el: '#app',
        data: {
            score: 98,
        },
    })

</script>

</html>
```

## 7 列表渲染

```python
# v-for 指令
	-可以循环：数组   v-for="(url,index) in urls"      位置不能换
  -可以循环：对象   v-for="(value,key) in obj"       如果只接收一个值，这个值就是value
  -可也循环：数字   v-for="i in num"       从1开始，循环到数字的个数
```



```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="./js/vue.js"></script>
    <title>标题</title>
    <style>


    </style>
</head>
<body>


<div id="app">
    <h1>把所有美女，一行行显示在页面中</h1>

    <ul>
        <!--        <li v-for="url in urls">-->
        <li v-for="(url,index) in urls">
            <h3>第{{index + 1}}张美女</h3>
            <img :src="url" alt="" height="100px" width="100px">
        </li>
    </ul>

    <h1>循环对象</h1>
<!--    <p v-for="(value,key) in obj">key值为：{{key}},value值为：{{value}}</p>-->
    <p v-for="value in obj">value值为：{{value}}</p>


    <h1>循环数字</h1>
    <p v-for="i in num">循环到了第：{{i}}</p>

</div>
</body>

<script>
    var vm = new Vue({
        el: '#app',
        data: {
            urls: ['https://img2.woyaogexing.com/2022/10/13/05e406595e217e0c!400x400.jpg',
                'https://img2.woyaogexing.com/2022/10/13/c03408591b068c18!400x400.jpg',
                'https://img2.woyaogexing.com/2022/10/13/f810d999375f7f1c!400x400.jpg'],
            obj: {name: 'lqz', age: 19, bobby: '篮球'} ,  // hash类型  hashmap  map  字典  对象 都是没有顺序
            num:4

        },
    })

</script>

</html>
```



### 使用v-if和v-for写个购物车显示与不显示的案例

```python
== 比较值是否一样
=== 比较类型和值是否一样
```



```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="./js/vue.js"></script>
    <link href="https://cdn.bootcss.com/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

    <title>标题</title>

</head>
<body>


<div id="app">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div v-if="!good_list.length==0">
                    <table class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>商品id号</th>
                            <th>商品名字</th>
                            <th>商品价格</th>
                            <th>商品数量</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr v-for="good in good_list">
                            <th scope="row">{{good.id}}</th>
                            <td>{{good.name}}</td>
                            <td>{{good.price}}</td>
                            <td>{{good.num}}</td>
                        </tr>

                        </tbody>

                    </table>
                </div>
                <div v-else>
                    空空如也
                </div>

                <hr>
                <button @click="handleClick">点我刷新购物车</button>
            </div>

        </div>


    </div>


</div>
</body>

<script>
    var vm = new Vue({
        el: '#app',
        data: {
            good_list: []
        },
        methods: {
            handleClick() {
                // 跟后端交互，拿到了数据
                this.good_list = [
                    {id: 1, name: '小汽车', price: 100000, num: 1},
                    {id: 2, name: '钢笔', price: 6, num: 10},
                    {id: 3, name: '脸盆', price: 12, num: 6},
                    {id: 4, name: '水杯', price: 66, num: 5},
                ]

            }
        }
    })

</script>

</html>
```





## 8 数据双向绑定

```python
# input ：text，password，select...
# text文本类型的双向数据绑定 
	-使用 :value='变量'   单向数据绑定，页面变化，变量不会跟着变---》一般不用
  -使用 v-model='变量'  双向数据绑定，页面变化，变量变化都会相互影响
# 使用
<input type="text" v-model="v">

```

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="./js/vue.js"></script>
    <link href="https://cdn.bootcss.com/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

    <title>标题</title>

</head>
<body>


<div id="app">

    <h1>v-model 只针对于input</h1>
    请输入内容：<input type="text" v-model="v"> ---->{{v}}


</div>
</body>

<script>
    var vm = new Vue({
        el: '#app',
        data: {
            v: '美女'
        },
    })

</script>

</html>
```



## 8 事件处理

```python
# 事件：click，dbclick   blur，     input，      change。。。
				单击    双击     失去焦点   输入内容      发生变化
  
  
# input框会有blur， input， change 事件
```

## 

### 代码

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="./js/vue.js"></script>

    <title>标题</title>

</head>
<body>


<div id="app">

    <h1>失去焦点事件blur</h1>
    <!--    请输入名字：<input type="text" v-model="name" @blur="handleBlur">-->
    <h1>change事件：数据发生变化才会触发</h1>
    <!--    请输入名字：<input type="text" v-model="name" @change="handleChange">-->
    <h1>input事件：只要输入内容会触发</h1>
    请输入名字：<input type="text" v-model="name" @input="handleInput">


</div>
</body>

<script>
    var vm = new Vue({
        el: '#app',
        data: {
            name: '彭于晏'
        },
        methods: {
            handleBlur() {
                alert(this.name)
            },
            handleChange() {
                console.log(this.name)  // 跟python中print一样
            },
            handleInput(){
                console.log(this.name)
            }
        }
    })

</script>

</html>
```





### 9.1 过滤案例

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="./js/vue.js"></script>

    <title>标题</title>

</head>
<body>


<div id="app">

    <h1>过滤案例</h1>
    <input type="text" v-model="search" @input="handleInput">
    <ul>
        <li v-for="item in newdataList">{{item}}</li>
    </ul>


</div>
</body>

<script>
    var vm = new Vue({
        el: '#app',
        data: {
            search: '',
            dataList: ['a', 'at', 'atom', 'atommon', 'be', 'beyond', 'cs', 'csrf', 'csrffe'],
            newdataList: ['a', 'at', 'atom', 'atommon', 'be', 'beyond', 'cs', 'csrf', 'csrffe']
        },
        methods: {
            handleInput() {
                // this 指向问题
                // 这个位置this是vue对象
                // var _this = this
                // this.dataList = this.dataList.filter(function (item) {
                //     console.log('----', _this) // this 还是vue对象吗？是浏览器对象
                //     return item.indexOf(_this.search) > -1
                // })

                // 使用es6的语法解决
                this.newdataList = this.dataList.filter(item => {
                    // console.log('----', this) // 如果使用剪头函数，this还是vue（剪头函数没有自己的this）
                    return item.indexOf(this.search) > -1
                })
            }
        }
    })


    // 补充：数组的内置方法，filter,传匿名函数进去，匿名函数如果返回true这个就保留，如果返回false，就不保留

    // var search = 'a'
    // var l = ['a', 'at', 'atom', 'atommon', 'be', 'beyond', 'cs', 'csrf', 'csrffe']
    // var ll = l.filter(function (item) {
    //     return item.indexOf(search) > -1
    // })
    // console.log(ll)

    // 补充：字符串有个indexOf，返回索引，如果大于-1，表示字字符串在当前字符串中
    // var s='lqz is handsome'
    // var res=s.indexOf('zoo') // 如果me在字符串中，就返回me在字符串的索引位置
    // console.log(res)


    // es6 的箭头函数
    // 传统写法
    // var a=function (name,age){
    //     console.log(name)
    // }
    // a("lxx")
    // //es6 箭头函数  匿名函数的另一种写法
    //  var a=  (name,age) =>{
    //     console.log(name)
    // }


</script>

</html>
```



### 9.2 事件修饰符

```python
# 放在事件后的
@click.once='函数'

.stop	只处理自己的事件，不再冒泡给父标签（阻止事件冒泡）
.self	只处理自己的事件，子控件冒泡的事件不处理
.prevent	阻止a链接的跳转
.once	事件只会触发一次（适用于抽奖页面）
```

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="./js/vue.js"></script>

    <title>标题</title>

</head>
<body>


<div id="app">

    <h1>点击子标签，父标签的事件也触发：事件冒泡</h1>
    <h2>阻止事件冒泡：点子标签，父标签不触发 stop</h2>
    <ul @click="handleUl">
        <li @click.stop="handleLi">点我看美女</li>
        <li>点我看帅哥</li>
    </ul>

    <h1>点击子标签，父标签的事件也触发：事件冒泡</h1>
    <h2>子标签的冒泡不处理：父标签写self，父标签只处理自己的事件，冒泡的事件不管</h2>
    <ul @click.self="handleUl">
        <li @click="handleLi">点我看美女</li>
        <li>点我看帅哥</li>
    </ul>

    <h1>prevent 阻止a链接的跳转</h1>
    <a href="http://www.liuqingzheng.top" @click.prevent="handleA">点我看美女</a>

    <h1>once 只执行一次</h1>
    <button @click.once="handleButton">点我秒杀</button>


</div>
</body>

<script>
    var vm = new Vue({
        el: '#app',
        data: {},
        methods: {
            handleLi() {
                console.log("li被点击了")
            },
            handleUl() {
                console.log("ul被点击了")
            },
            handleA() {
                console.log('a被点击了,不会再跳转了')
            },
            handleButton() {
                alert('秒杀成功')
            }
        }
    })

</script>

</html>
```

### .3 按键修饰符

```python
# 事件：input，change   除此之外还有 【按键】被按下和被抬起的事件

```



```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="./js/vue.js"></script>

    <title>标题</title>

</head>
<body>


<div id="app">

    <h1>按键修饰符</h1>
<!--    <input type="text" @keyup="handleKeyUp($event)">-->
    <input type="text" @keyup.enter="handleKeyUp($event)">
    <input type="text" @keyup.esc="handleKeyUp($event)">
    <input type="text" @keyup.="handleKeyUp($event)">


</div>
</body>

<script>
    var vm = new Vue({
        el: '#app',
        data: {},
        methods:{
            handleKeyUp(event){
                console.log('sdasfd')
               if(event.code=='Enter') {
                   console.log('enter键被抬起了，开始搜索')
               }
            }
        }

    })

</script>

</html>
```



## 

